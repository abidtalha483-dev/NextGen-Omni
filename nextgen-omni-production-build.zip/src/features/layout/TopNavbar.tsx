import React from 'react';
import { Undo2, Redo2, Scissors, Download, User, ChevronDown } from 'lucide-react';

export default function TopNavbar() {
  return (
    <nav className="h-12 border-b border-nextgen-panel bg-nextgen-dark flex items-center justify-between px-4 z-50">
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-nextgen-accent rounded-lg flex items-center justify-center font-bold text-xs shadow-lg shadow-nextgen-accent/20">O</div>
          <input 
            defaultValue="Untitled Project 01" 
            className="bg-transparent border-none outline-none text-sm font-medium focus:ring-1 focus:ring-nextgen-accent rounded px-2"
          />
        </div>
        <div className="flex items-center gap-1 border-l border-nextgen-panel pl-4">
          <button className="p-1.5 hover:bg-white/10 rounded-md transition-colors"><Undo2 size={16} /></button>
          <button className="p-1.5 hover:bg-white/10 rounded-md transition-colors"><Redo2 size={16} /></button>
          <div className="w-px h-4 bg-nextgen-panel mx-1" />
          <button className="p-1.5 hover:bg-white/10 rounded-md transition-colors text-nextgen-accent"><Scissors size={16} /></button>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <button className="flex items-center gap-2 px-4 py-1.5 bg-nextgen-accent hover:bg-blue-600 rounded-full text-xs font-bold transition-all shadow-lg shadow-blue-500/20">
          <Download size={14} /> Export
        </button>
        <div className="flex items-center gap-2 pl-3 border-l border-nextgen-panel">
          <div className="w-7 h-7 bg-nextgen-purple rounded-full flex items-center justify-center text-[10px]"><User size={14} /></div>
          <ChevronDown size={14} className="opacity-50" />
        </div>
      </div>
    </nav>
  );
}