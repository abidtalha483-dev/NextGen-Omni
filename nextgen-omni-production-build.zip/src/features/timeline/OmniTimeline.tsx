import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { useEditorStore } from '@/store/useEditorStore';
import { Scissors, Trash2, ZoomIn, ZoomOut } from 'lucide-react';

const TRACKS = [
  { id: 1, name: 'Video 1', type: 'video', color: 'bg-blue-600/20 border-blue-500' },
  { id: 2, name: 'Audio 1', type: 'audio', color: 'bg-emerald-600/20 border-emerald-500' },
  { id: 3, name: 'Text 1', type: 'text', color: 'bg-orange-600/20 border-orange-500' },
];

const PX_PER_SEC = 20;

export default function OmniTimeline() {
  const { clips, currentTime, seekTo, selectedClipId, updateClip } = useEditorStore();
  const timelineRef = useRef<HTMLDivElement>(null);

  const handleTimelineClick = (e: React.MouseEvent) => {
    if (!timelineRef.current) return;
    const rect = timelineRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left + timelineRef.current.scrollLeft;
    seekTo(x / PX_PER_SEC);
  };

  return (
    <div className="h-64 border-t border-nextgen-panel bg-nextgen-dark flex flex-col">
      <div className="h-10 border-b border-nextgen-panel flex items-center justify-between px-4">
        <div className="flex items-center gap-4">
          <button className="text-zinc-500 hover:text-white"><Scissors size={14} /></button>
          <button className="text-zinc-500 hover:text-red-500"><Trash2 size={14} /></button>
        </div>
        <div className="flex items-center gap-4">
          <ZoomOut size={14} className="text-zinc-500" />
          <div className="w-32 h-1 bg-zinc-800 rounded-full cursor-pointer">
            <div className="w-1/2 h-full bg-nextgen-accent rounded-full" />
          </div>
          <ZoomIn size={14} className="text-zinc-500" />
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        <div className="w-[72px] border-r border-nextgen-panel flex flex-col bg-nextgen-dark z-10">
          {TRACKS.map(track => (
            <div key={track.id} className="h-12 border-b border-nextgen-panel flex items-center justify-center text-[10px] font-bold text-zinc-500">
              {track.name}
            </div>
          ))}
        </div>

        <div 
          ref={timelineRef}
          className="flex-1 overflow-x-auto overflow-y-hidden relative select-none scrollbar-hide"
          onClick={handleTimelineClick}
        >
          <div className="absolute top-0 h-6 w-full border-b border-nextgen-panel flex">
             {Array.from({ length: 50 }).map((_, i) => (
               <div key={i} className="border-l border-zinc-800 h-full min-w-[100px] text-[8px] text-zinc-600 pl-1">
                 00:00:{i < 10 ? `0${i}` : i}
               </div>
             ))}
          </div>

          <div className="mt-6 relative h-full">
            {/* Tracks Container */}
            {TRACKS.map(track => (
              <div key={track.id} className="h-12 border-b border-white/5 relative w-[5000px]">
                {clips.filter(c => c.trackId === track.id).map(clip => (
                  <motion.div
                    key={clip.id}
                    drag="x"
                    dragMomentum={false}
                    onDragEnd={(_, info) => {
                       const newStart = clip.startTime + (info.offset.x / PX_PER_SEC);
                       updateClip(clip.id, { startTime: Math.max(0, newStart) });
                    }}
                    className={`absolute h-8 top-2 rounded border-l-4 cursor-pointer z-20 ${track.color} ${
                      selectedClipId === clip.id ? 'ring-2 ring-white ring-inset' : ''
                    }`}
                    style={{ 
                      left: clip.startTime * PX_PER_SEC, 
                      width: clip.duration * PX_PER_SEC 
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      useEditorStore.setState({ selectedClipId: clip.id });
                    }}
                  >
                    <span className="text-[9px] font-bold px-2 truncate block">{clip.type.toUpperCase()} CLIP</span>
                  </motion.div>
                ))}
              </div>
            ))}

            {/* Playhead */}
            <div 
              className="absolute top-0 bottom-0 w-px bg-red-500 z-50 pointer-events-none"
              style={{ left: currentTime * PX_PER_SEC }}
            >
              <div className="w-3 h-3 bg-red-500 absolute -top-1.5 -left-1.5 rotate-45" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}