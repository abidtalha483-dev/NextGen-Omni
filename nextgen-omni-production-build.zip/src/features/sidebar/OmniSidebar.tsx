import React, { useState } from 'react';
import { Video, Music, Type, Sticker, Sparkles, Layers, Image } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useEditorStore } from '@/store/useEditorStore';
import { OMNI_DB } from '@/data/OmniAssetDatabase';

const NAV_ITEMS = [
  { id: 'media', icon: Image, label: 'Media' },
  { id: 'video', icon: Video, label: 'Videos' },
  { id: 'audio', icon: Music, label: 'Audio' },
  { id: 'text', icon: Type, label: 'Text' },
  { id: 'stickers', icon: Sticker, label: 'Stickers' },
  { id: 'effects', icon: Sparkles, label: 'Effects' },
  { id: 'transitions', icon: Layers, label: 'Transitions' },
];

export default function OmniSidebar() {
  const [activeTab, setActiveTab] = useState('video');
  const addClip = useEditorStore((state) => state.addClip);

  return (
    <div className="flex h-full bg-nextgen-dark select-none">
      <div className="w-[72px] border-r border-nextgen-panel flex flex-col items-center py-4 gap-4">
        {NAV_ITEMS.map((item) => (
          <button 
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center gap-1 group transition-all ${
              activeTab === item.id ? 'text-nextgen-accent' : 'text-zinc-500 hover:text-white'
            }`}
          >
            <item.icon size={20} className={activeTab === item.id ? 'scale-110' : ''} />
            <span className="text-[10px] font-medium">{item.label}</span>
          </button>
        ))}
      </div>
      <div className="w-72 flex flex-col">
        <div className="p-4 flex items-center justify-between">
          <h2 className="font-bold capitalize text-sm">{activeTab}</h2>
        </div>
        <div className="flex-1 overflow-y-auto px-4 scrollbar-hide">
          <div className="grid grid-cols-2 gap-2 pb-4">
            {OMNI_DB.Videos.map((video) => (
              <motion.div 
                key={video.id}
                whileHover={{ scale: 1.02 }}
                className="aspect-video bg-nextgen-panel rounded-md overflow-hidden relative group cursor-pointer border border-transparent hover:border-nextgen-accent"
                onClick={() => addClip({
                  trackId: 1, 
                  type: 'video', 
                  url: video.url, 
                  duration: video.duration, 
                  startTime: 0, 
                  properties: { scale: 1, opacity: 1, volume: 1, x: 0, y: 0 }
                })}
              >
                <img src={video.url} className="w-full h-full object-cover" alt="" />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="text-[10px] bg-nextgen-accent px-2 py-0.5 rounded-full font-bold">ADD</span>
                </div>
                <div className="absolute bottom-1 right-1 text-[8px] bg-black/60 px-1 rounded">{video.duration}s</div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}