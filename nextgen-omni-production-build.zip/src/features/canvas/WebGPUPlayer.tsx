import React from 'react';
import { Play, Pause, SkipBack, SkipForward, Maximize } from 'lucide-react';
import { useEditorStore } from '@/store/useEditorStore';

export default function WebGPUPlayer() {
  const { isPlaying, togglePlay, currentTime, clips } = useEditorStore();
  
  return (
    <div className="flex-1 flex flex-col p-8">
      <div className="flex-1 relative bg-zinc-950 rounded-lg shadow-2xl overflow-hidden border border-white/5 flex items-center justify-center aspect-video mx-auto max-h-[80%]">
        {/* Simulated WebGPU Layer */}
        <div className="absolute inset-0 bg-gradient-to-br from-zinc-900 to-black" />
        
        {/* Layer Rendering Logic */}
        {clips.map(clip => {
          const isVisible = currentTime >= clip.startTime && currentTime <= (clip.startTime + clip.duration);
          if (!isVisible) return null;
          return (
            <div 
              key={clip.id} 
              className="absolute transition-all duration-75"
              style={{
                transform: `scale(${clip.properties.scale}) translate(${clip.properties.x}px, ${clip.properties.y}px)`,
                opacity: clip.properties.opacity
              }}
            >
              {clip.type === 'video' && <img src={clip.url} className="max-w-full max-h-full" alt="" />}
            </div>
          );
        })}

        {/* Center UI Overlay */}
        {!isPlaying && clips.length === 0 && (
          <div className="relative z-10 text-zinc-700 font-bold uppercase tracking-widest text-xl">Preview Ready</div>
        )}
      </div>
      
      {/* Playback Controls */}
      <div className="h-16 flex items-center justify-center gap-6">
        <button className="text-zinc-400 hover:text-white transition-colors"><SkipBack size={20} /></button>
        <button 
          onClick={togglePlay}
          className="w-12 h-12 bg-white text-black rounded-full flex items-center justify-center hover:scale-105 transition-all"
        >
          {isPlaying ? <Pause fill="black" size={24} /> : <Play fill="black" size={24} className="translate-x-0.5" />}
        </button>
        <button className="text-zinc-400 hover:text-white transition-colors"><SkipForward size={20} /></button>
        <div className="absolute right-12 text-zinc-500 font-mono text-xs">
          {new Date(currentTime * 1000).toISOString().substr(14, 8)}
        </div>
      </div>
    </div>
  );
}