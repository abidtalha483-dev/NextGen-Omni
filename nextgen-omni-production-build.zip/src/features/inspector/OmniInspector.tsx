import React from 'react';
import * as Slider from '@radix-ui/react-slider';
import { useEditorStore } from '@/store/useEditorStore';

export default function OmniInspector() {
  const { selectedClipId, clips, updateClip } = useEditorStore();
  const clip = clips.find(c => c.id === selectedClipId);

  if (!clip) {
    return (
      <aside className="w-72 border-l border-nextgen-panel flex flex-col items-center justify-center text-zinc-600 p-8 text-center">
        <div className="w-12 h-12 rounded-full border-2 border-dashed border-zinc-800 mb-4" />
        <p className="text-xs">Select a clip on the timeline to adjust properties</p>
      </aside>
    );
  }

  const handlePropChange = (key: string, val: number) => {
    updateClip(clip.id, { properties: { ...clip.properties, [key]: val } });
  };

  return (
    <aside className="w-72 border-l border-nextgen-panel flex flex-col">
      <div className="p-4 border-b border-nextgen-panel">
        <h2 className="font-bold text-sm uppercase tracking-wider">Properties</h2>
      </div>
      <div className="p-4 space-y-6">
        <div className="space-y-3">
          <label className="text-[11px] text-zinc-400 flex justify-between uppercase font-bold">
            Scale <span>{Math.round((clip.properties.scale || 1) * 100)}%</span>
          </label>
          <Slider.Root 
            className="relative flex items-center select-none touch-none w-full h-5"
            value={[clip.properties.scale || 1]}
            max={2} step={0.01} min={0}
            onValueChange={([val]) => handlePropChange('scale', val)}
          >
            <Slider.Track className="bg-zinc-800 relative grow rounded-full h-[3px]">
              <Slider.Range className="absolute bg-nextgen-accent rounded-full h-full" />
            </Slider.Track>
            <Slider.Thumb className="block w-3 h-3 bg-white shadow-xl rounded-full focus:outline-none" />
          </Slider.Root>
        </div>

        <div className="space-y-3">
          <label className="text-[11px] text-zinc-400 flex justify-between uppercase font-bold">
            Opacity <span>{Math.round((clip.properties.opacity || 1) * 100)}%</span>
          </label>
          <Slider.Root 
            className="relative flex items-center select-none touch-none w-full h-5"
            value={[clip.properties.opacity || 1]}
            max={1} step={0.01} min={0}
            onValueChange={([val]) => handlePropChange('opacity', val)}
          >
            <Slider.Track className="bg-zinc-800 relative grow rounded-full h-[3px]">
              <Slider.Range className="absolute bg-nextgen-accent rounded-full h-full" />
            </Slider.Track>
            <Slider.Thumb className="block w-3 h-3 bg-white shadow-xl rounded-full focus:outline-none" />
          </Slider.Root>
        </div>
      </div>
    </aside>
  );
}