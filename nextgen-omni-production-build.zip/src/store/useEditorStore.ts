import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';

export type ClipType = 'video' | 'audio' | 'text' | 'effect';

export interface Clip {
  id: string;
  trackId: number;
  type: ClipType;
  url: string;
  duration: number;
  startTime: number;
  properties: {
    scale: number;
    opacity: number;
    volume: number;
    x: number;
    y: number;
    text?: string;
    color?: string;
  };
}

interface EditorState {
  clips: Clip[];
  currentTime: number;
  isPlaying: boolean;
  selectedClipId: string | null;
  addClip: (clip: Omit<Clip, 'id'>) => void;
  updateClip: (id: string, updates: Partial<Clip>) => void;
  deleteClip: (id: string) => void;
  seekTo: (time: number) => void;
  togglePlay: () => void;
}

export const useEditorStore = create<EditorState>((set) => ({
  clips: [],
  currentTime: 0,
  isPlaying: false,
  selectedClipId: null,
  addClip: (clip) => set((state) => ({ clips: [...state.clips, { ...clip, id: uuidv4() }] })),
  updateClip: (id, updates) => set((state) => ({
    clips: state.clips.map(c => c.id === id ? { ...c, ...updates } : c)
  })),
  deleteClip: (id) => set((state) => ({ clips: state.clips.filter(c => c.id !== id) })),
  seekTo: (time) => set({ currentTime: time }),
  togglePlay: () => set((state) => ({ isPlaying: !state.isPlaying })),
}));