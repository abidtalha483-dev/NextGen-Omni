import TopNavbar from '@/features/layout/TopNavbar';
import OmniSidebar from '@/features/sidebar/OmniSidebar';
import WebGPUPlayer from '@/features/canvas/WebGPUPlayer';
import OmniInspector from '@/features/inspector/OmniInspector';
import OmniTimeline from '@/features/timeline/OmniTimeline';

export default function NextGenOmni() {
  return (
    <div className="h-screen w-screen bg-nextgen-dark text-white flex flex-col overflow-hidden">
      <TopNavbar />
      <div className="flex flex-1 min-h-0">
        <OmniSidebar />
        <main className="flex-1 flex flex-col min-w-0 border-x border-nextgen-panel">
          <div className="flex-1 relative bg-black">
            <WebGPUPlayer />
          </div>
          <OmniTimeline />
        </main>
        <OmniInspector />
      </div>
    </div>
  );
}