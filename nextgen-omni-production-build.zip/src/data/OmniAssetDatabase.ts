export const OMNI_DB = {
  Videos: Array.from({ length: 8 }).map((_, i) => ({
    id: `v-${i}`,
    title: `Cinematic Shot ${i}`,
    url: `https://images.pexels.com/photos/853168/pexels-photo-853168.jpeg?auto=compress&cs=tinysrgb&w=400`,
    duration: 10
  })),
  Audio: [
    { id: 'a1', title: 'Whoosh SFX', url: '', duration: 2, type: 'sfx' },
    { id: 'a2', title: 'Cinematic Pulse', url: '', duration: 30, type: 'music' }
  ],
  TextPresets: [
    { id: 't1', title: 'Neon Glow', style: 'neon' },
    { id: 't2', title: '3D Block', style: '3d' }
  ]
};